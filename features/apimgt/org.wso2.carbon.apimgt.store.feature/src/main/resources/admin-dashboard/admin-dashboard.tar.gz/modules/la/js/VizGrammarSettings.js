var vizgSettings = {
    colorScale: ["#343B59","#5a638c","#396B94","#438CAD","#BBBCCD","#597CC3"]
}